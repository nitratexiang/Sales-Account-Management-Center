#!/usr/bin/env python3
"""
Store Sales & Discount Dashboard — build pipeline.

Turns an Odoo invoice-report export + store master data + a list-price (WSP)
table into ONE self-contained HTML file with every row inlined.

    python3 build_dashboard.py --config config.json
    python3 build_dashboard.py --demo --out demo.html

The pipeline is intentionally dependency-light: openpyxl for .xlsx (read-only),
stdlib csv for .csv. Nothing is written back to the input files.
"""

import argparse
import csv
import datetime as dt
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import unicodedata
from collections import OrderedDict, defaultdict

try:
    from openpyxl import load_workbook
except ImportError:  # csv-only usage still works without openpyxl
    load_workbook = None

HERE = os.path.dirname(os.path.abspath(__file__))
DEFAULT_TEMPLATE = os.path.join(HERE, os.pardir, "assets", "dashboard_template.html")

RE_INJECT_CONFIG = re.compile(r"(/\* ==INJECT:CONFIG_START== \*/).*?(/\* ==INJECT:CONFIG_END== \*/)", re.S)
RE_INJECT_DATA = re.compile(r"(/\* ==INJECT:DATA_START== \*/).*?(/\* ==INJECT:DATA_END== \*/)", re.S)
RE_SCRIPT = re.compile(r"<script>(.*?)</script>", re.S)


# --------------------------------------------------------------------------
# generic helpers
# --------------------------------------------------------------------------

def norm_name(raw, strip_suffixes=("old",)):
    """Normalise a company name so invoice partners and master rows can join.

    Handles the three things that actually break joins in practice:
    accents/diacritics, punctuation & legal-form noise, and stale suffixes.
    """
    s = unicodedata.normalize("NFKD", str(raw or ""))
    s = "".join(c for c in s if not unicodedata.combining(c))
    s = s.lower().replace("&", " and ")
    s = re.sub(r"[^a-z0-9]+", " ", s).strip()
    for suf in strip_suffixes:
        s = re.sub(r"\b%s\b\s*$" % re.escape(suf.lower()), "", s).strip()
    return re.sub(r"\s+", " ", s)


def is_col_letter(spec):
    return isinstance(spec, str) and re.fullmatch(r"[A-Za-z]{1,2}", spec or "") is not None


def cell(row, spec, default=None):
    """Read a value from a header-keyed row.

    spec may be: header name, list of candidate header names, an Excel column
    letter ("D"), or a 1-based column number.
    """
    if spec is None:
        return default
    specs = spec if isinstance(spec, list) else [spec]
    for one in specs:
        if one is None:
            continue
        if isinstance(one, int):
            vals = row.get("__cells", [])
            if 0 < one <= len(vals):
                v = vals[one - 1]
                if v not in (None, ""):
                    return v
            continue
        if is_col_letter(one):
            idx = 0
            for ch in one.upper():
                idx = idx * 26 + (ord(ch) - 64)
            vals = row.get("__cells", [])
            if 0 < idx <= len(vals):
                v = vals[idx - 1]
                if v not in (None, ""):
                    return v
            continue
        for key in (one, str(one).strip(), str(one).strip().lower()):
            if key in row and row[key] not in (None, ""):
                return row[key]
    return default


def to_float(v):
    if v is None or v == "":
        return None
    if isinstance(v, (int, float)):
        return float(v)
    s = str(v).strip().replace("\u00a0", "").replace(" ", "")
    s = re.sub(r"[^\d,.\-]", "", s)
    if s in ("", "-", "."):
        return None
    if "," in s and "." in s:
        s = s.replace(",", "") if s.rfind(".") > s.rfind(",") else s.replace(".", "").replace(",", ".")
    elif "," in s:
        s = s.replace(",", ".") if len(s.split(",")[-1]) in (1, 2) else s.replace(",", "")
    try:
        return float(s)
    except ValueError:
        return None


def to_month(v):
    """Return the month number (1-12) of a date-ish value."""
    if v is None or v == "":
        return None
    if isinstance(v, (dt.datetime, dt.date)):
        return v.month
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        s = str(int(v))
        if len(s) == 8:
            return int(s[4:6])
        if len(s) == 6:
            return int(s[4:6])
        return None
    s = str(v).strip()
    m = re.match(r"^(\d{4})[-/](\d{1,2})[-/](\d{1,2})", s)
    if m:
        return int(m.group(2))
    m = re.match(r"^(\d{1,2})[-/](\d{1,2})[-/](\d{2,4})", s)
    if m and int(m.group(2)) <= 12:
        return int(m.group(2))
    m = re.match(r"^([A-Za-z]{3,})", s)
    if m:
        for fmt in ("%b %d, %Y", "%B %d, %Y", "%d %b %Y", "%d %B %Y"):
            try:
                return dt.datetime.strptime(s, fmt).month
            except ValueError:
                pass
    return None


def read_table(path, sheet=None, header_row=1):
    """Read .xlsx / .csv into a list of dicts (header named + `__cells` list)."""
    ext = os.path.splitext(path)[1].lower()
    if ext in (".xlsx", ".xlsm"):
        if load_workbook is None:
            raise RuntimeError("openpyxl is required to read %s" % path)
        wb = load_workbook(path, read_only=True, data_only=True)
        ws = wb[sheet] if sheet else wb[wb.sheetnames[0]]
        rows = []
        for i, r in enumerate(ws.iter_rows(values_only=True), start=1):
            if i < header_row:
                continue
            rows.append(list(r))
        wb.close()
    else:
        with open(path, newline="", encoding="utf-8-sig") as fh:
            rows = [r for r in csv.reader(fh)]
    if not rows:
        return [], []
    header = [("" if h is None else str(h)).strip() for h in rows[header_row - 1]]
    out = []
    for r in rows[header_row:]:
        if not any(x not in (None, "") for x in r):
            continue
        row = OrderedDict()
        for i, h in enumerate(header):
            if h:
                row[h] = r[i] if i < len(r) else None
        row["__cells"] = list(r)
        out.append(row)
    return header, out


# --------------------------------------------------------------------------
# demo data (synthetic, obviously fake — never company data)
# --------------------------------------------------------------------------

DEMO_INVOICE_COLUMNS = {
    "store": "Parent Company",
    "date": "Invoice Date",
    "model": "Product",
    "qty": "Product Quantity",
    "revenue": "Untaxed Total",
    "price": "List Price",
}
DEMO_STORE_COLUMNS = {
    "name": "Name",
    "type": "Customer Type",
    "ranking": "Customer Ranking",
    "pricelist": "Pricelist",
    "dtype": "Discount Type",
    "drate": "Discount Rate",
    "salesperson": "Salesperson",
    "country": "Country",
}

DEMO_MODELS = [("MODEL C1 Pro", 1499.0), ("MODEL C1", 1199.0), ("MODEL V2", 2199.0)]
DEMO_STORES = [
    ("Demo Cycles Alpha", "KeyAccount", "a", "KeyAccount", "KeyAccount", "KeyAccount", "demo.rep.one", "Germany"),
    ("Demo Bikes Beta", "BuyingGroupA", "b", "5% discount", "Union 50-99 pieces", "5%", "demo.rep.two", "France"),
    ("Demo Store Gamma", "BuyingGroupB", "c", "5% discount", "Union 20-50 pieces", "5%", "demo.rep.two", "Netherlands"),
    ("Demo Shop Delta", "Union", "d", "3% discount", "BuyingGroupA 25-74 pieces", "3%", "demo.rep.one", "Belgium"),
    ("Demo Retail Epsilon", "Independent", "e", "Public Pricelist", "no discount", "0%", "demo.rep.three", "Italy"),
    ("Demo Outlet Zeta", "Independent", "e", "Public Pricelist", "no discount", "0%", "demo.rep.three", "Spain"),
]


def demo_tables():
    """Build synthetic invoice / store / pricing tables (no real data)."""
    inv_rows = []
    for i, (name, _t, _r, _p, _dt, _dr, _sp, _c) in enumerate(DEMO_STORES):
        for month in range(1, 10):
            for j, (model, price) in enumerate(DEMO_MODELS):
                if (i + month + j) % 3 == 0:
                    continue
                qty = float(3 + ((i * 7 + month * 3 + j * 5) % 26))
                if i == 0 and month == 5 and j == 1:
                    qty = -qty / 2.0  # a credit note, to exercise the net-volume caliber
                rate = 1.0 - (0.03 + 0.01 * ((i + j) % 5))
                rev = round(price * qty * rate, 2)
                inv_rows.append({
                    DEMO_INVOICE_COLUMNS["store"]: name,
                    DEMO_INVOICE_COLUMNS["date"]: "%04d-%02d-%02d" % (2026, month, min(28, 3 + month)),
                    DEMO_INVOICE_COLUMNS["model"]: model,
                    DEMO_INVOICE_COLUMNS["qty"]: qty,
                    DEMO_INVOICE_COLUMNS["revenue"]: rev,
                    DEMO_INVOICE_COLUMNS["price"]: price,
                })
    store_rows = [{DEMO_STORE_COLUMNS[k]: v for k, v in zip(
        ["name", "type", "ranking", "pricelist", "dtype", "drate", "salesperson", "country"], s)} for s in DEMO_STORES]
    store_rows.append({DEMO_STORE_COLUMNS["name"]: "Demo Cycles Alph\u00e4 (branch)",
                       DEMO_STORE_COLUMNS["country"]: "Germany"})
    return {
        "invoices": [{"conf": {"region": "EU", "currency": "\u20ac"}, "rows": inv_rows}],
        "stores": [{"conf": {}, "rows": store_rows}],
        "pricing": [],
    }


def demo_config():
    return {
        "title": "Sales Performance Dashboard · DEMO",
        "subtitle": "Synthetic demo data — every store, model and number on this page is fake.",
        "year": 2026,
        "regions": {
            "EU": {"label": "EU", "currency": "\u20ac",
                   "filters": ["type", "ranking", "dtype", "salesperson", "country"],
                   "summaryExtra": ["type", "ranking"]},
            "UK": {"label": "UK", "currency": "\u00a3", "filters": ["ranking", "salesperson"], "summaryExtra": []},
        },
        "typeOrder": ["KeyAccount", "BuyingGroupA", "BuyingGroupB", "Union", "Independent", "Unknown"],
        "dtypeOrder": ["KeyAccount", "BuyingGroupA 25-74 pieces", "Union 20-50 pieces",
                       "Union 50-99 pieces", "no discount"],
        "ranks": ["a", "b", "c", "d", "e", "strategic"],
        "tierDefaults": {"Independent": [0, 24], "Union": [0, 24],
                         "BuyingGroupA": [0, 19], "BuyingGroupB": [0, 19]},
        "annualizeFactor": 1.5,
        "pieGroups": [
            {"label": "Key accounts", "color": "#f59e0b", "types": ["KeyAccount"]},
            {"label": "Buying groups", "color": "#8b5cf6", "types": ["BuyingGroupA", "BuyingGroupB"]},
            {"label": "Independents", "color": "#10b981", "types": ["Union", "Independent", "Unknown"]},
        ],
        "invoices": {"columns": DEMO_INVOICE_COLUMNS},
        "stores": {"columns": DEMO_STORE_COLUMNS},
        "pricing": {"files": []},
        "exclude": [],
    }


# --------------------------------------------------------------------------
# pipeline
# --------------------------------------------------------------------------

IO_KEYS = ("invoices", "stores", "pricing", "exclude", "template", "output", "__comment")

REGION_KEYS = ("label", "currency", "filters", "summaryExtra")


def load_inputs(cfg, base):
    """Read every configured table from disk into memory."""
    tables = {"invoices": [], "stores": [], "pricing": []}

    for f in (cfg.get("invoices", {}) or {}).get("files", []) or []:
        path = os.path.join(base, f["path"])
        header, rows = read_table(path, f.get("sheet"), f.get("headerRow", 1))
        tables["invoices"].append({"conf": f, "rows": rows, "header": header, "path": path})

    for f in (cfg.get("stores", {}) or {}).get("files", []) or []:
        path = os.path.join(base, f["path"])
        header, rows = read_table(path, f.get("sheet"), f.get("headerRow", 1))
        tables["stores"].append({"conf": f, "rows": rows, "header": header, "path": path})

    for f in (cfg.get("pricing", {}) or {}).get("files", []) or []:
        path = os.path.join(base, f["path"])
        header, rows = read_table(path, f.get("sheet"), f.get("headerRow", 1))
        tables["pricing"].append({"conf": f, "rows": rows, "header": header, "path": path})

    return tables


def build_pricing(cfg, tables):
    """(region, model) -> list price, plus base-model fallbacks."""
    price = {}
    for t in tables["pricing"]:
        region = t["conf"].get("region", "")
        for row in t["rows"]:
            model = cell(row, t["conf"].get("model", "Model"))
            if not model:
                continue
            p = to_float(cell(row, t["conf"].get("price", "Price")))
            if p is not None:
                price[(region, str(model).strip())] = p
    fallback = (cfg.get("pricing", {}) or {}).get("modelFallback", {}) or {}
    return price, fallback


def build_store_master(cfg, tables):
    """normalised-name-key -> store info dict, from the store master file(s)."""
    scols = (cfg.get("stores", {}) or {}).get("columns", {}) or {}
    strip = tuple((cfg.get("stores", {}) or {}).get("nameNoise", ["old"]))
    info = OrderedDict()

    for t in tables["stores"]:
        f_reg = t["conf"].get("region")
        for row in t["rows"]:
            raw = cell(row, scols.get("name", "Name"))
            if raw in (None, ""):
                continue
            key = norm_name(raw, strip)
            if not key or key in info:
                continue
            info[key] = {
                "name": str(raw).strip(),
                "type": cell(row, scols.get("type"), "") or "",
                "ranking": cell(row, scols.get("ranking"), "") or "",
                "pricelist": cell(row, scols.get("pricelist"), "") or "",
                "dtype": cell(row, scols.get("dtype"), "") or "",
                "drate": cell(row, scols.get("drate"), "") or "",
                "salesperson": cell(row, scols.get("salesperson"), "") or "",
                "country": cell(row, scols.get("country"), "") or "",
                "region": (cell(row, scols.get("region"), "") or f_reg or ""),
                "cur": "",
            }
    return info, strip


def lookup_store(info, raw, strip, head_office=True):
    """Match an invoice partner name against the master index."""
    if raw in (None, ""):
        return None
    k = norm_name(raw, strip)
    if k in info:
        return info[k]
    if head_office and "," in str(raw):
        for part in str(raw).split(","):
            pk = norm_name(part, strip)
            if pk in info:
                return info[pk]
    return None


def build_dataset(cfg, tables, verbose=True):
    """Aggregate invoices into the dashboard DATA payload."""
    icols = (cfg.get("invoices", {}) or {}).get("columns", {}) or {}
    price_map, fallback = build_pricing(cfg, tables)
    info, strip = build_store_master(cfg, tables)

    unmapped = defaultdict(int)
    missing_price = defaultdict(int)
    agg = OrderedDict()
    seen_region = {}
    rows_in = 0
    sales_rows_out = 0

    def list_price(region, model):
        p = price_map.get((region, model))
        return price_map.get(("", model)) if p is None else p

    for t in tables["invoices"]:
        conf = t["conf"]
        region = conf.get("region", "")
        currency = conf.get("currency", "")
        for row in t["rows"]:
            rows_in += 1
            model = cell(row, icols.get("model"))
            if model in (None, ""):
                continue
            model = str(model).strip()
            qty = to_float(cell(row, icols.get("qty", "Product Quantity")))
            if qty is None:
                continue
            mm = to_month(cell(row, icols.get("date")))
            raw_store = cell(row, icols.get("parent")) or cell(row, icols.get("store"))
            st = lookup_store(info, raw_store, strip)

            sk = None
            if st is not None:
                sk = norm_name(st["name"], strip)
                if not st.get("region"):
                    st["region"] = region
                if not st.get("cur"):
                    st["cur"] = currency
            else:
                sk = norm_name(raw_store, strip)
                if not sk:
                    continue
                unmapped[str(raw_store).strip()] += 1
                if sk not in info:
                    info[sk] = {
                        "name": str(raw_store).strip(), "type": "", "ranking": "", "pricelist": "",
                        "dtype": "", "drate": "", "salesperson": "", "country": "",
                        "region": region, "cur": currency,
                    }
            seen_region.setdefault(sk, region)

            # list price: explicit column wins, otherwise the pricing table
            price = to_float(cell(row, icols.get("price")))
            if price is None:
                price = list_price(region, model)
                fb = (fallback.get(region) or {}).get(model)
                if price is None and fb:
                    price = list_price(region, fb)
            if price is None:
                missing_price[model] += 1

            revenue = to_float(cell(row, icols.get("revenue")))
            key = (sk, region, mm, model)
            cur = agg.get(key)
            if cur is None:
                cur = agg[key] = {"sk": sk, "region": region, "mm": mm, "p": model,
                                  "qty": 0.0, "rev": 0.0, "price": price, "cur": currency}
            cur["qty"] += qty
            if revenue is not None:
                cur["rev"] += revenue
            if cur["price"] is None and price is not None:
                cur["price"] = price

    # resolve region for stores that only show up in the master file
    for sk, st in info.items():
        if not st.get("region"):
            st["region"] = seen_region.get(sk, "")

    # currency per store comes from its region config
    regions = cfg.get("regions", {}) or {}
    for st in info.values():
        rc = regions.get(st.get("region")) or {}
        if rc.get("currency"):
            st["cur"] = rc["currency"]

    rows = []
    for v in agg.values():
        if v["price"] not in (None, 0) and v["qty"]:
            v["rate"] = v["rev"] / (v["price"] * v["qty"])
        else:
            v["rate"] = None
        rows.append({"sk": v["sk"], "mm": v["mm"], "p": v["p"], "qty": round(v["qty"], 4),
                     "price": v["price"], "rate": (None if v["rate"] is None else round(v["rate"], 6)),
                     "region": v["region"], "cur": v["cur"]})
        sales_rows_out += 1

    # region exclusions (e.g. UK rows leaking into the EU site export)
    removed = 0
    for rule in cfg.get("exclude", []) or []:
        field, region, values = rule.get("field"), rule.get("region"), [str(x).lower() for x in rule.get("values", [])]
        drop = {k for k, st in info.items()
                if (region in (None, "", st.get("region"))) and str(st.get(field, "")).lower() in values}
        if drop:
            removed += len(drop)
            for k in drop:
                info.pop(k, None)
            rows = [r for r in rows if r["sk"] not in drop]

    data = {"store_info": {k: v for k, v in info.items()}, "sales": rows}

    report = {
        "rows_read": rows_in,
        "sales_rows": sales_rows_out,
        "stores": len(data["store_info"]),
        "stores_with_sales": len({r["sk"] for r in rows}),
        "net_qty": round(sum(r["qty"] for r in rows), 2),
        "unmapped_partners": sorted(unmapped.items(), key=lambda x: -x[1]),
        "missing_price_models": sorted(missing_price.items(), key=lambda x: -x[1]),
        "excluded_stores": removed,
        "by_region": {},
    }
    for rid in regions:
        rr = [r for r in rows if r["region"] == rid]
        if not rr:
            continue
        list_total = sum((r["price"] or 0) * r["qty"] for r in rr)
        actual_total = sum((r["rate"] or 0) * (r["price"] or 0) * r["qty"] for r in rr)
        report["by_region"][rid] = {
            "qty": round(sum(r["qty"] for r in rr), 2),
            "stores": len({r["sk"] for r in rr}),
            "months": sorted({r["mm"] for r in rr if r["mm"]}),
            "weighted_rate": (round(actual_total / list_total, 4) if list_total else None),
        }
    return data, report


# --------------------------------------------------------------------------
# render + verify
# --------------------------------------------------------------------------

def render(cfg, data, template_path, out_path):
    tpl = open(template_path, encoding="utf-8").read()
    cfg_out = {k: v for k, v in cfg.items() if k not in IO_KEYS and not k.startswith("__")}
    cfg_js = json.dumps(cfg_out, ensure_ascii=False, indent=2)
    data_js = json.dumps(data, ensure_ascii=False, separators=(",", ":"))
    if data_js.lower().find("</script") >= 0:
        raise ValueError("data contains a </script sequence")
    tpl, n1 = RE_INJECT_CONFIG.subn(lambda m: m.group(1) + "\nconst CONFIG = " + cfg_js + ";\n" + m.group(2), tpl, count=1)
    tpl, n2 = RE_INJECT_DATA.subn(lambda m: m.group(1) + "\nconst DATA = " + data_js + ";\n" + m.group(2), tpl, count=1)
    if n1 != 1 or n2 != 1:
        raise RuntimeError("template injection markers not found (config:%d data:%d)" % (n1, n2))
    with open(out_path, "w", encoding="utf-8") as fh:
        fh.write(tpl)
    return out_path


def verify(out_path):
    """Cheap self-check: the inlined script must parse, and totals must agree."""
    html = open(out_path, encoding="utf-8").read()
    m = RE_SCRIPT.search(html)
    if not m:
        return "no <script> found"
    js = m.group(1)
    node = shutil.which("node")
    if not node:
        return "node not found — skipped syntax check"
    with tempfile.NamedTemporaryFile("w", suffix=".js", delete=False, encoding="utf-8") as fh:
        fh.write(js)
        tmp = fh.name
    try:
        p = subprocess.run([node, "--check", tmp], capture_output=True, text=True)
        return "script syntax OK" if p.returncode == 0 else "SYNTAX ERROR: " + (p.stderr or "").strip()
    finally:
        os.unlink(tmp)


def main():
    ap = argparse.ArgumentParser(description="Build the store sales & discount dashboard.")
    ap.add_argument("--config", help="path to the JSON config")
    ap.add_argument("--out", help="output html path (overrides config.output)")
    ap.add_argument("--template", help="override the template html")
    ap.add_argument("--demo", action="store_true", help="build with synthetic demo data (no config needed)")
    ap.add_argument("--quiet", action="store_true")
    args = ap.parse_args()

    if args.demo:
        cfg, tables, base = demo_config(), demo_tables(), os.getcwd()
    else:
        if not args.config:
            ap.error("--config is required unless --demo is used")
        cfg_path = os.path.abspath(args.config)
        base = os.path.dirname(cfg_path)
        with open(cfg_path, encoding="utf-8") as fh:
            cfg = json.load(fh)
        tables = load_inputs(cfg, base)

    template = os.path.abspath(args.template or cfg.get("template") or DEFAULT_TEMPLATE)
    if not os.path.isabs(template) and not os.path.exists(template):
        template = os.path.join(base, template)
    out_path = os.path.abspath(args.out or cfg.get("output") or "dashboard.html")

    data, report = build_dataset(cfg, tables)
    render(cfg, data, template, out_path)
    status = verify(out_path)

    if not args.quiet:
        print("=" * 68)
        print("rows read          :", report["rows_read"])
        print("sales aggregates   :", report["sales_rows"])
        print("stores (master+new):", report["stores"], "/ with sales:", report["stores_with_sales"])
        print("net qty (units)    :", report["net_qty"])
        if report["excluded_stores"]:
            print("excluded stores    :", report["excluded_stores"])
        for rid, r in report["by_region"].items():
            months = r["months"]
            span = "%s-%s" % (months[0], months[-1]) if months else "—"
            print("  region %-6s : qty %-10s stores %-6s months %-7s weighted rate %s" % (
                rid, r["qty"], r["stores"], span,
                "—" if r["weighted_rate"] is None else "%.2f%%" % (r["weighted_rate"] * 100)))
        if report["unmapped_partners"]:
            print("\npartners not in the store master (%d) — shown as Unknown:" % len(report["unmapped_partners"]))
            for name, n in report["unmapped_partners"][:15]:
                print("   %-52s %d rows" % (name[:52], n))
        if report["missing_price_models"]:
            print("\nmodels without a list price (%d) — qty counted, rate shows —:" % len(report["missing_price_models"]))
            for name, n in report["missing_price_models"][:15]:
                print("   %-52s %d rows" % (name[:52], n))
        print("\noutput  :", out_path, "(%.1f KB)" % (os.path.getsize(out_path) / 1024.0))
        print("check   :", status)
        print("=" * 68)
    if status.startswith("SYNTAX ERROR"):
        sys.exit(1)


if __name__ == "__main__":
    main()
