# UI conventions and the visual spec

The dashboard is regenerated often, and a rebuild must not change how it looks.
This file records the layout, the design tokens and the behaviours that have to
stay stable, plus the CSS hooks the runtime depends on.

---

## 1. Page order (do not reorder)

```
header            title (dashboard name · regions · period) + one-line caliber
└ card  Filters   region tabs → filter selects → store search → month → hint
└ card  Overview  active filter blocks + headline stats + monthly bars
└ card  Summary   one row per store (hidden while a single store is selected)
└ card  Details   by model (always visible)
└ card  Pies      volume + revenue distribution
```

Every section is a white card with a small uppercase heading that carries a
short accent bar. The card order mirrors the reading order of the analysis:
narrow → totals → per store → per model → portfolio mix.

---

## 2. Design tokens

| Token | Value | Used for |
|---|---|---|
| Header gradient | `#1d3f8f → #2b5bc4 → #3f74e0` | header band (with two decorative radial glows) |
| Primary | `#2b5bc4` / `#3f74e0` | active tab, active button, stat numbers, bars |
| Page background | `#eef1f7` with a soft vertical gradient | body |
| Card | `#fff`, radius `16px`, border `#e9edf5`, two-layer soft shadow | every card |
| Inner block | gradient `#fbfcff → #f5f8fd`, border `#e7ecf6`, radius `12px` | info blocks, stats, pie boxes |
| Text | `#1e293b` primary, `#5b6478` headings, `#8a93a8` muted labels | — |
| Good / Warn / Bad | `#0c8a5b` / `#e28600` / `#d3382f` | rate bands, judgements |
| Bar gradient | `#6a9bff → #2b5bc4` | monthly volume bars |
| Type tags | one pastel pair per customer type, assigned by index in `typeOrder` (`t-0` … `t-7`, cycling) | store type chips |

Rules of taste that matter here: radius grows with nesting (16 → 12 → 8),
shadow is always soft and never grey-black, and colour is reserved for meaning
(rate band, active state, type tag) instead of decoration.

---

## 3. Filters

- **Region tabs** are a segmented control at the top of the filter card. They
  come first because they redefine everything below them. A single-region build
  hides the control entirely.
- **Which filters exist is a per-region decision** (`regions.<R>.filters`).
  A region only gets the filters whose values actually vary inside it: a site
  with one country has no country filter; a site with no customer-type taxonomy
  has no type filter and no discount-type filter. Showing a filter with one
  possible value is noise, not neutrality.
- **Filter order** is stable: customer type → ranking → discount type →
  salesperson → country → store search.
- **Switching region resets every condition** and rebuilds each select from the
  new region's stores. Never carry a selection across regions — a salesperson
  from one region must not appear as an option in the other.
- **Month options are derived from the data** (`YYYY-MM` labels, values are the
  month number). Never hardcode 12 months: a region that reports to August has
  no September option, and the pie/period copy must follow the real coverage.
- **Store search** is a combobox: focus/typing opens a filtered list (capped at
  120 entries), the list shows `Name (Type)`, Escape or a click outside closes
  it, and a small × clears the selection. It sits last in the row because it is
  the terminal action, not a filter dimension.

---

## 4. Tables

Both tables share one look: sticky uppercase header on `#f6f8fc`, zebra rows,
hover highlight, right-aligned numeric columns with tabular figures, and a
max-height container with a slim scrollbar.

| Table | Columns |
|---|---|
| Store summary | Store · Total Qty · Avg Discount Rate · *region extras* |
| Details | Product · Qty · Discount Rate · Set Unit Price · Actual Selling Price |

- `summaryExtra` decides which extra columns a region gets. A region without a
  meaningful type/ranking shows only the first three columns, and the empty
  state's `colspan` follows the column count — never leave a hardcoded span.
- The first column is wide (38%) and wraps; everything numeric is right-aligned.
- Two decimals for money, integer-ish for quantities, one decimal for rates.

---

## 5. Charts

- **Monthly bars** are plain divs, not a chart library: one column per month,
  value label above, month label below, height normalised to the tallest month
  and floored at 2px so an empty month still shows a stub. Counts on the bars
  are quantities; the bars never encode revenue.
- **Pies** are hand-built SVG arcs with a centred total and a legend that
  carries the absolute value *and* the share. They follow the region only.
  Widths are percentages, so a group that disappears simply has no slice.
- No external chart dependency: the file must render offline, from a mail
  attachment, with no network.

---

## 6. Copy and formats

- Money: `€1,499.00` / `£1,066.00` — currency symbol from the region config,
  two decimals, thousands separator, no space after the symbol.
- Quantities: thousands separator, up to two decimals, no unit suffix — the
  column heading carries "units".
- Rates: one decimal and a `%`, `—` when unknown. Keep `—` (not `0%`) for
  *unknown*; `0%` would read as a real measurement.
- Missing values everywhere are `—`. Never render an empty cell, `null`,
  `undefined` or `NaN`.
- Headings are sentence case with an uppercase small-caps style; identifiers
  inside them (filters, store names, models) keep their own casing.
- Titles follow `<Dashboard name> · <Regions> · <Period>`, e.g.
  `Sales Performance Dashboard · EU + UK · Jan–Sep 2026`. The period in the
  title must match the real coverage of the data.

---

## 7. Translation / reskinning

All strings live in `CONFIG.labels` (and `filterLabels`, `cols`, `stat`,
`judg` inside it). To ship a non-English dashboard, override those keys in the
config — no template edit, no risk of breaking logic. Templates that carry a
`{placeholder}` (rate percentages, estimated volume, tier range) are filled by
the runtime, so keep the braces when translating.

---

## 8. CSS hooks the runtime depends on

The markup is data-driven, so **renaming or deleting a class silently breaks a
view**. Before restyling, check this list — every one of these classes is
referenced by the runtime:

```
.layout    .header .wrap .card .filters .fgroup .flabel .hint
.filters   .region-tabs .rtab(.active) .combobox .cblist .cbitem .cbempty .cbclear
.blocks    .blkrow .blk .k .v  (.v.good/.v.bad)
.stats     .statrow .stat .n .l
.vbars     .chartwrap .barcol .bar .barval .barlabel
.tables    .tablewrap table th td .num .bad .warn .good .empty
.tags      .tag .t-0 … .t-7   (index in CONFIG.typeOrder)
.pies      .piestack .piebox .piewrap .legend .lg .dot .nm .pct
```

The failure mode to remember: replacing the stylesheet wholesale and forgetting
the five bar classes leaves the monthly chart as vertical unreadable text
because the flex column wrapper is gone. After any restyle, render the file and
count: card count, bar count, table row count, pie slice count.

---

## 9. Empty and edge states

- No stores survive the filters → both tables show the empty message; stats go
  to `0` and the rate to `—`.
- A store with no rows in the selected month → summary stats show the month
  range as `—` and the details table shows the empty message.
- A region with no data at all → the tab still exists, the view is empty rather
  than broken; do not hide it (an empty region is information).
- Long store and model names wrap in the first column; never truncate with an
  ellipsis, a truncated store name is worse than a tall row.
