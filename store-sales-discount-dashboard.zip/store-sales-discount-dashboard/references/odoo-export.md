# Getting the data (Odoo `account.invoice.report` + master data)

Three inputs are needed. The invoice export is the only strictly required one;
without the store master every store shows as *Unknown* and without a list
price the rate column stays empty.

---

## 1. Invoice report — the volume and revenue source

Model: `account.invoice.report` (read via XML-RPC / `web_search_read`).

Recommended filters:

| Dimension | Filter |
|---|---|
| Channel | `team_id` in the offline sales-team ids |
| Document type | `move_type` in `out_invoice`, `out_refund` (credit notes must be included) |
| State | exclude `draft`, `checked`, `cancel` |
| Period | `invoice_date` between the first and last day of the reporting year |
| Product family | product category = complete bikes (e.g. `product_categ_id = 11`) |

Fields that matter downstream:

| Field | Used as |
|---|---|
| `partner_id` / `commercial_partner_id` | store (roll up to the parent company) |
| `invoice_date` | month |
| product / `bike_model` name | model |
| `product_qty` (`Product Quantity`) | net quantity — negative on credit notes |
| `price_subtotal` / untaxed total | net revenue |
| `team_id`, country | sanity checks |

### Pitfall 1 — pagination silently truncates

`web_search_read` reports a `count` that is capped by `count_limit` (default
10 001). If the export loop `break`s on that number, you get roughly the first
third of the year and a total that looks plausible but is wrong. Always call
`search_count` for the real total first, then paginate until you have it, and
assert the row count at the end. This is the single most expensive mistake made
in this pipeline: a truncated pull *looks* like a complete one.

### Pitfall 2 — prefix expressions balance domain terms

When the domain is written as a prefix (Polish) expression, every field
condition must be present in the right number. Duplicated or dropped
`product_categ_id` terms silently change the result set. Prefer the
OR-style list domain and re-count after any edit.

### Pitfall 3 — one site, one export

Each Odoo site (main EU instance, UK instance, …) has its own database, its own
price list and its own currency. Export separately and tag each file with its
region + currency in the config; never merge the files before the build.

### Pitfall 4 — a foreign-country partner in the "wrong" export

It is normal for a handful of invoices of the other site's country to appear in
the main export (cross-border ordering, legacy accounts). They show up as a
small country line that shouldn't be there. Handle it with an `exclude` rule in
the config rather than by hand, so the exclusion is reproducible.

---

## 2. List price table — the benchmark

Keep the company's price list in one workbook with **one sheet per region**
(`Price-EU`, `Price-UK`, …), each with at least a model column and a
WSP/list-price column, in the sheet's own currency.

Rules that avoid almost all join failures:

1. Match on the **complete model string**, including version suffixes. A `V1`
   of the same bike is a different row and often a different price.
2. Never carry a price across regions — the currencies differ.
3. Where a version is genuinely missing from a regional price list, declare an
   explicit `pricing.modelFallback` (e.g. the `V1` of a model resolves to the
   base model's price). Declared fallbacks are auditable; guessed prices are not.
4. Models with no price at all stay blank. The build report lists them — chase
   them rather than letting a blank price quietly skew the averages.

The fastest setup is to add the list-price column **into the invoice export**
(the config's `invoices.columns.price`), keeping the price lookup outside the
dashboard build. The `pricing` block exists for when that is not possible.

---

## 3. Store master — the reference dimension

Build it from `res.partner`:

| Column | Source |
|---|---|
| `Name` | `display_name` of the company |
| `Customer Type` | the customer-tag / category that classifies the store |
| `Customer Ranking` | `customer_ranking` |
| `Pricelist` | `property_product_pricelist` |
| `Salesperson` | `user_id` |
| `Country` | `country_id` |
| `Discount Type` / `Discount Rate` | looked up from the discount-tier table (below) |
| `Region` | optional; otherwise assigned from the invoice file the store appears in |

Practical notes:

- Filter `is_company = True` and select by customer tags, one pass per type
  (key account / alliance / buying group / independent / regular). A store can
  legitimately fall out of every tag: keep a catch-all "regular" pass so the
  master covers the whole customer base.
- Keep a stable, small column set (name + ranking + pricelist + salesperson +
  tags is usually enough) plus the fields the dashboard actually renders.
  Forty-column exports make the master unmaintainable.
- Some store groups arrive as a separate list from the business (a union or
  buying-group membership export). Split the catch-all list by normalised name
  match and log the handful of unmatched names instead of dropping them.
- One store, one row. Where the same organisation appears twice, keep the head
  office row and let the pipeline's name normalisation handle the branches.

### Discount tier table

The tier table maps *customer type + committed volume* to a discount type and a
percentage. Fold it into the master as two columns:

- `Discount Type` — the ladder label, written so the dashboard can parse a
  range out of it (`<name> <lo>-<hi> pieces`, or `<name> over <n> pieces`);
- `Discount Rate` — `X%`, or a non-numeric marker (used for key accounts
  that negotiate case by case, where a percentage would be meaningless).

Stores whose committed volume falls below the first paid tier get
`no discount` / `0%` — write that explicitly instead of leaving the cells
empty, so the "extra discount" judgement can run.

### Optional: committed volume

If the tier logic also needs committed pre-order volume, aggregate
`sale.blanket.order` lines (net of cancellations) per partner and add it as a
column. Watch for two things: the exported sheet often repeats the partner only
on the first line of a block (fill down before aggregating), and order type
lines must be filtered to complete bikes so spare-part orders don't inflate the
commitment.

---

## 4. Export shape and hygiene

- Export to `.xlsx` with a **fixed header row** and stable column order; then
  the pipeline config never changes between refreshes. Both header names and
  Excel column letters are accepted, so a legacy layout can be used as-is.
- Keep the raw exports in a `data/` folder next to the config and never edit
  them. Fixes belong in the config (exclusions, fallbacks) or in the master.
- Before building, spot-check three numbers by hand: total net quantity, total
  net revenue and the weighted rate of one familiar store. If one of the three
  is off, the problem is upstream, not in the dashboard.
- Re-run the build after any refresh. The build script prints a report with
  rows read, aggregates, store counts, per-region volume/rate, unmatched
  partner names and unpriced models — read it every time; it is the cheapest
  quality gate available.
