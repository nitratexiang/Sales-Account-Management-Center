# Methodology — sales, discount rate and the two judgements

This is the reasoning behind the dashboard: what each number means, how it is
computed, and which comparisons are legitimate. It is the reference to read
before changing a formula or answering a question about a figure.

---

## 1. The question the dashboard answers

> For every offline store, what margin did the transaction actually realise —
> and does that match the discount the company granted it based on committed
> volume?

To answer it, three datasets are joined:

| Dataset | Role |
|---|---|
| Invoice report | What was actually invoiced: store, month, model, quantity, net revenue |
| List price table | The reference price a unit *should* sell at (excluding tax) |
| Store master | Who the store is: type, ranking, price list, granted discount tier, owner, country |

The dashboard then shows volume, unit price and realised rate per store and
per model, plus two verdicts: **extra discount** and **tier status**.

Delivery is a **single HTML file with every row inlined** — no server, no
external assets, no build step at the recipient's end. Forward it by mail or
chat and it opens in any browser.

---

## 2. Calibers (write these down before touching a formula)

### 2.1 Volume — net, never gross

Volume is **forward invoices minus credit notes**:

- documents: sales invoice (`out_invoice`) **and** credit note (`out_refund`,
  carried as a negative quantity/amount);
- excluded states: draft / checked / cancelled;
- so a returned unit cancels itself out, and a store's total is a *net* figure.
  Never report the forward-invoice count alone as "sales".

### 2.2 Scope — one channel, one product family, one period

- **Channel**: the offline sales teams only (B2C web orders and inter-company
  movements are out of scope). In Odoo this is the sales-team filter.
- **Product family**: complete bikes only, never spare parts. Filter on the
  product category, not on a name match.
- **Period**: invoice date inside the reporting year. Report the coverage you
  actually have (e.g. "Jan–Sep") rather than implying twelve months.
- **Region**: each Odoo site is its own world. Two sites ⇒ two regions ⇒ two
  tabs, two currencies, and **no cross-region total**. A row belonging to the
  other site's country must be excluded explicitly (see `exclude` in the config).

### 2.3 Store identity — roll up to the head office

Invoices are often addressed to a branch, a shop, or a delivery address. Match
the partner's **parent company** so the whole organisation lands on one row.

Names do not join cleanly on their own. `normalise()` in the pipeline strips
diacritics, punctuation and legal-form noise, lowercases, and removes stale
suffixes (`- old`), then retries the comma-separated head of composite names.
Anything left unmatched is reported by the build script and still appears on
the dashboard as an **Unknown** store, so no volume is silently lost. Treat a
long unmatched list as a data-quality task, not as a rounding error.

### 2.4 List price — the region's own price table

The list price is the company's published price (WSP) for that model, in that
region's currency, **excluding tax**.

- Join on the **complete model string**. Versioned models (`… Pro V1`) usually
  have their own row; do not strip the version suffix before matching.
- If a model is genuinely absent from a price list, define an explicit
  fallback to its base model in `pricing.modelFallback`; do not invent a price.
- If no price can be resolved, the quantity still counts but the rate shows
  `—`. Watch the "models without a list price" list in the build report: a
  missing price silently distorts every average below it.

### 2.5 The rate — a realisation rate, not a list-price discount

```
list value      = list unit price × net qty          (per model)
actual revenue  = net untaxed revenue                (from the invoice report)
rate            = actual revenue ÷ list value         (aggregate: Σ actual ÷ Σ list)
```

Read it as *the share of list price the store actually paid*:

| rate | meaning |
|---|---|
| 1.00 | sold at list, no discount at all |
| 0.90 | 10% off list |
| > 1.00 | sold **above** list — either a data error or a deliberate surcharge; flagged red |

Two traps worth remembering:

1. **Always aggregate on value, not on the ratio.** "Average rate" on the
   dashboard is `Σ actual ÷ Σ list` (volume-weighted). A plain mean of per-row
   rates over-weights a 2-unit row exactly as much as a 200-unit row.
2. **A single unit price cannot carry a mixed basket.** Where rows for the same
   model carry different list prices (different price lists, mid-year change),
   the displayed unit price is the value-weighted average, and it is shown next
   to the rate so the pair stays internally consistent.

### 2.6 What "average" means per view

| View | Weighting |
|---|---|
| Store | all of that store's rows, weighted by list value |
| Filters overview | every row of the stores surviving the filters, weighted by list value |
| Monthly bar | net quantity only (no value weighting) |

---

## 3. The two judgements

Both judgments are attached to a **single store** (a store-level decision, not
a portfolio-level one), and both intentionally ignore the month filter — a
verdict that shifts when you click a month is not a verdict.

### 3.1 Extra discount — did the deal deviate from the granted tier?

```
granted rate  = the "X%" recorded in the store master next to its discount type
realised rate = actual revenue ÷ list value, over all months
sum           = granted rate + realised rate
```

| sum | verdict |
|---|---|
| ≥ 1.00 | **Normal** — the realised price is at or above the level implied by the granted discount |
| 0.985 – 1.00 | **Slight** — up to 1.5% additional discount leaked into the deal |
| < 0.985 | **Severe** — more than 1.5% extra discount; the store is paying less than its tier |

Stores whose granted discount is not a percentage (e.g. a key-account tier
negotiated case by case) get `—` rather than a false verdict.

### 3.2 Tier status — is the discounted volume actually being delivered?

The discount ladder is expressed in committed pieces, and the master data
records it as text such as `Wholesale 75-149 pieces` or `Union over 200 pieces`.
The dashboard parses the low and high bound out of that string.

```
estimated year-end volume = volume to date × annualiseFactor
```

`annualiseFactor` converts the elapsed period into a full year (1.5 for
January–September; change it when the reporting period changes — it is a
config value, not a constant).

| comparison | verdict |
|---|---|
| estimate > upper bound | **Upgrade** — already beyond the tier's range; the store is over-delivering for its discount |
| lower ≤ estimate ≤ upper | **Maintain** — the tier still fits |
| estimate < lower bound | **Downgrade** — the store no longer earns the tier |

If the recorded discount type has no range (typically `no discount`), fall back
to `tierDefaults[type]`: the band just below the first paid tier. Without that
fallback every no-discount store would show `—`, hiding the most common case —
a store that was granted nothing yet is invoiced at a discount.

---

## 4. Page structure

Top to bottom:

1. **Title bar** — data source and caliber in one line.
2. **Region tabs** — one tab per site/currency. Switching rebuilds every
   option: filter choices, month choices, tables, charts.
3. **Filters** — the region decides which filters exist (see
   `references/ui-conventions.md`). Month options are derived from the data, so
   a region that only reports to August simply has no September option.
4. **Overview card** — the active filter conditions, headline stats (volume,
   stores, months, weighted rate) and the monthly volume bars.
5. **Store summary** — one row per store, sorted by volume, only while no
   single store is selected.
6. **Details** — by model. With no store selected it aggregates the current
   filter scope; with a store selected it becomes that store's model mix.
7. **Distribution pies** — volume and revenue by customer group, following the
   active region and deliberately ignoring the other filters, so they always
   answer "how is this region made up overall".

### 4.1 Selecting a store

The store picker is a search box over the stores that survive the filters,
showing the type next to the name. Selecting one replaces the summary with the
store's own cards: master-data blocks, stats, the two judgements, the monthly
bars and the model table.

### 4.2 Rate colouring

| band | colour |
|---|---|
| rate > 1.0 (above list / abnormal) | red |
| rate > 0.93 | green — healthy realisation |
| 0.80 – 0.93 | amber — worth a conversation |
| < 0.80 | red — deep discounting |

Thresholds live in `rateBands`; they encode the company's tolerance, not a
universal truth.

---

## 5. Formula cheat sheet

```
net qty                  = Σ quantity (invoices + credit notes)
list unit price          = published WSP of that model, that region, ex-tax
list value               = list unit price × net qty
actual net revenue       = Σ untaxed revenue
rate                     = actual net revenue ÷ list value
weighted avg rate (view) = Σ actual ÷ Σ list
actual selling price     = rate × list unit price
granted rate             = the % in the store master
extra discount           = 1 − (granted rate + realised rate)   [0 = none]
est. year-end volume     = volume to date × annualiseFactor
tier verdict             = est. volume vs the parsed [lo, hi] of the tier
```

---

## 6. Caveats worth repeating in any handover

- **The rate is not a discount.** It is the fraction of list price invoiced.
  Say "realised rate 89%" or "11% off list" — both are correct; "discount rate
  89%" is not.
- **Regions are isolated.** Never sum EU and UK, and never sum across
  currencies.
- **Comparisons across a partial period are weaker.** The tier judgement
  extrapolates; if the period is 3 months, the extrapolation is doing more work
  than the data.
- **A store with no sales in the period is not a zero-rate store** — it simply
  has no rows and will not appear in the summary.
- **Store master quality drives everything.** Type, ranking, granted discount
  and country come from master data; a wrong tier there produces a wrong verdict
  everywhere downstream.
- **Keep the master and the invoice export aligned in time.** Comparing
  January–September invoices against a tier table that changed in June mixes
  two regimes; note the effective date when reporting.
